package com.oono.oonomod.regi;

import com.oono.oonomod.item.ItemoonoIngot;
import com.oono.oonomod.item.tool.TooloonoPickaxe;
import com.oono.oonomod.item.tool.Tooloonosword;
import com.oono.oonomod.main.oonomod;
import net.minecraft.world.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ObjectHolder;

@ObjectHolder(oonomod.MOD_ID)
public class oonomodItems {

    public static final ItemoonoIngot OONO_INGOT = new ItemoonoIngot();
    public static final TooloonoPickaxe OONO_PICKAXE = new TooloonoPickaxe();
    public static final Tooloonosword OONO_SWORD = new Tooloonosword();

    @Mod.EventBusSubscriber(modid = oonomod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static class Register{

        @SubscribeEvent
        public static void registerItems(final RegistryEvent.Register<Item> event){

            final Item[] items = {
                    OONO_INGOT,
                    OONO_PICKAXE,
                    OONO_SWORD
            };
            event.getRegistry().registerAll(items);
        }
    }
}
